package org.iesbelen.dao;

import org.iesbelen.model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class UsuarioDAOImpl extends AbstractDAOImpl implements UsuarioDAO {


    @Override
    public void create(Usuario usuario) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rsGenKeys = null;

        try {
            conn = connectDB();

            ps = conn.prepareStatement("INSERT  INTO usuarios (usuario, contraseña, rol) VALUES (?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);

            int idx =1;
            ps.setString(idx++, usuario.getNombreUsuario());
            ps.setString(idx++, usuario.getContraseña());
            ps.setString(idx, usuario.getRol());

            int rows = ps.executeUpdate();
            if (rows == 0) System.out.println("INSERT de fabricante con 0 filas insertadas.");

            rsGenKeys = ps.getGeneratedKeys();

            if (rsGenKeys.next()) usuario.setId(rsGenKeys.getInt(1));

        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeDb(conn, ps, rsGenKeys);
        }


    }

    @Override
    public List<Usuario> getAll() {
        Connection conn = null;
        ResultSet rs = null;
        Statement st = null;
        List<Usuario> listaUsuarios = new ArrayList<>();

        try {
            conn = connectDB();

            st = conn.createStatement();

            rs = st.executeQuery("SELECT * FROM usuarios");

            while (rs.next()){
                Usuario usuario = new Usuario();
                int idx = 1;
                usuario.setId(rs.getInt(idx++));
                usuario.setNombreUsuario(rs.getString(idx++));
                usuario.setContraseña(rs.getString(idx++));
                usuario.setRol(rs.getString(idx));

                listaUsuarios.add(usuario);
            }

        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeDb(conn, st, rs);
        }

        return listaUsuarios;
    }

    @Override
    public Optional<Usuario> find(int id) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = connectDB();

            ps = conn.prepareStatement("SELECT * FROM usuarios WHERE id = (?)");

            ps.setInt(1, id);

            rs = ps.executeQuery();

            if (rs.next()){
                Usuario usuario = new Usuario();
                int idx = 1;
                usuario.setId(rs.getInt(idx++));
                usuario.setNombreUsuario(rs.getString(idx++));
                usuario.setContraseña(rs.getString(idx++));
                usuario.setRol(rs.getString(idx));
                return Optional.of(usuario);
            }
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return Optional.empty();
    }

    @Override
    public void delete(int id) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;


        try {
            conn = connectDB();

            ps = conn.prepareStatement("DELETE FROM usuarios WHERE id = ?");

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows == 0) System.out.println("Delete de fabricante con 0 registros eliminados.");

        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeDb(conn, ps, rs);
        }

    }

    @Override
    public void update(Usuario usuario) {
        final String sql = "UPDATE usuarios SET usuario = ?, contraseña = ?, rol = ? WHERE id = ?";

        try (Connection conn = connectDB();
        PreparedStatement ps = conn.prepareStatement(sql)){
            int idx = 1;

            ps.setString(idx++, usuario.getNombreUsuario());
            ps.setString(idx++, usuario.getContraseña());
            ps.setString(idx++, usuario.getRol());
            ps.setInt(idx, usuario.getId());

            int rows = ps.executeUpdate();

            if (rows == 0) System.out.println("No se ha eliminido ningun registro");


        } catch (SQLException | ClassNotFoundException e){
            e.printStackTrace();
        }

    }

    @Override
    public Usuario findByUsuarioYPassword(String usuario, String password) {
        return null;
    }
}
