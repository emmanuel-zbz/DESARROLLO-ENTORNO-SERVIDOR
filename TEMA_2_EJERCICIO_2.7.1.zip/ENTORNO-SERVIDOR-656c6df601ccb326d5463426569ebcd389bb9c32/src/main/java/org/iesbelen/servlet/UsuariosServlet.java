package org.iesbelen.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
// Importaciones de DAO/Model...
import org.iesbelen.dao.UsuarioDAO;
import org.iesbelen.dao.UsuarioDAOImpl;
import org.iesbelen.model.Usuario;

import java.io.IOException;
import java.util.Optional;

@WebServlet(name = "usuariosServlet", value = "/tienda/usuarios/*")
public class UsuariosServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        RequestDispatcher dispatcher; // Declaración
        String pathInfo = request.getPathInfo();

        // 1. Manejar la ruta principal /tienda/usuarios o /tienda/usuarios/
        if (pathInfo == null || "/".equals(pathInfo)){
            UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

            request.setAttribute("listaUsuarios", usuarioDAO.getAll());
            dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");

        } else {
            // 2. Manejar rutas específicas (/crear, /{id}, /editar/{id})
            pathInfo = pathInfo.replaceAll("/$", "");
            String[] pathParts = pathInfo.split("/");

            // 2a. Ruta /crear
            if (pathParts.length == 2 && "crear".equals(pathParts[1])){
                // Nota: Corregido /jps/ a /jsp/
                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/crear-usuarios.jsp");

                // 2b. Ruta /detalle/{id}
            } else if (pathParts.length == 2){ // Asume que es un ID
                UsuarioDAO usuarioDao = new UsuarioDAOImpl();

                try {
                    Optional<Usuario> usuarioOptional = usuarioDao.find(Integer.parseInt(pathParts[1]));

                    if (usuarioOptional.isPresent()){
                        Usuario usuario = usuarioOptional.get();
                        request.setAttribute("usuario", usuario);
                        dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/detalle-usuarios.jsp");
                    } else {
                        response.sendRedirect(request.getContextPath() + "/tienda/usuarios");
                        return; // Detiene la ejecución aquí, vital después de sendRedirect
                    }

                } catch (NumberFormatException e){
                    e.printStackTrace();
                    // Si el ID no es un número, vuelve a la lista
                    dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");
                }

                // 2c. Ruta /editar/{id}
            } else if (pathParts.length == 3 && "editar".equals(pathParts[1])){
                UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

                try{
                    Optional<Usuario> usuarioOptional = usuarioDAO.find(Integer.parseInt(pathParts[2]));

                    if (usuarioOptional.isPresent()){
                        Usuario usuario = usuarioOptional.get();
                        request.setAttribute("usuario", usuario);
                        dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/editar-usuarios.jsp");
                    } else {
                        response.sendRedirect(request.getContextPath() + "/tienda/usuarios");
                        return; // Detiene la ejecución aquí, vital después de sendRedirect
                    }

                } catch (NumberFormatException e){
                    e.printStackTrace();
                    // Si el ID no es un número, vuelve a la lista
                    dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");
                }

                // 2d. Ruta por defecto (catch-all para rutas no soportadas)
            } else {
                System.out.println("Opción GET no soportada: " + pathInfo);
                // Envía a la página principal por defecto o a un 404
                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");
            }
        }

        // Ejecución garantizada del forward
        dispatcher.forward(request, response);
    }



}