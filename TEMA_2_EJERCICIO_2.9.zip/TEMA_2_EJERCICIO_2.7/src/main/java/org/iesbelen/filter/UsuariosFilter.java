package org.iesbelen.filter;

import java.io.IOException;
import java.util.Optional;
import java.util.Set;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.iesbelen.model.Usuario;

/**
 * Servlet Filter implementation class UsuariosFilter
 */
@WebFilter(
        urlPatterns = "/tienda/usuarios/*",
        initParams = @WebInitParam(name = "acceso-concedido-a-rol", value = "administrador")
)
public class UsuariosFilter extends HttpFilter implements Filter {

    private String rolAcceso;

    /**
     * @see HttpFilter#HttpFilter()
     */
    public UsuariosFilter() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see Filter#destroy()
     */
    public void destroy() {
        // TODO Auto-generated method stub
    }

    /**
     * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
     */
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {


        //Cast de ServletRequest a HttpServletRequest, el único tipo implementado
        //en el contenedor de Servlet: HttpServletRequest & HttpServletReponse
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        //Obteniendo la url
        String url = httpRequest.getRequestURL().toString();

        if (url.endsWith("/login") || url.endsWith("/login/")) {
            chain.doFilter(request, response);
            return;
        }


        //Accediendo al objeto de sesión
        HttpSession session = httpRequest.getSession();
        Usuario usuario = null;

        if (session != null
                && (usuario = (Usuario) session.getAttribute("usuario-logado")) != null
                && this.rolAcceso.equals(usuario.getRol())) {

            chain.doFilter(request, response);

        } else {

            httpResponse.sendRedirect(httpRequest.getContextPath() + "/tienda/usuarios/login");
        }


    }

    /**
     * @see Filter#init(FilterConfig)
     */
    public void init(FilterConfig fConfig) throws ServletException {

        this.rolAcceso = fConfig.getInitParameter("acceso-concedido-a-rol");

    }
}