package org.iesbelen.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
// Importaciones de DAO/Model...
import jakarta.servlet.http.HttpSession;
import org.iesbelen.dao.UsuarioDAO;
import org.iesbelen.dao.UsuarioDAOImpl;
import org.iesbelen.model.Usuario;

import java.io.IOException;
import java.util.Optional;

@WebServlet(name = "usuariosServlet", value = "/tienda/usuarios/*")
public class UsuariosServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        RequestDispatcher dispatcher;
        String pathInfo = request.getPathInfo();

        if (pathInfo == null || "/".equals(pathInfo)) {
            UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

            request.setAttribute("listaUsuarios", usuarioDAO.getAll());
            dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");

        } else {
            pathInfo = pathInfo.replaceAll("/$", "");
            String[] pathParts = pathInfo.split("/");


            if (pathParts.length == 2 && "crear".equals(pathParts[1])) {

                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/crear-usuarios.jsp");

            } else if (pathParts.length == 2 && "login".equals(pathParts[1])) {


                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/login.jsp");
            } else if (pathParts.length == 2) {

                //ESTO ES usuarios/${id}
                UsuarioDAO usuarioDao = new UsuarioDAOImpl();

                try {
                    Optional<Usuario> usuarioOptional = usuarioDao.find(Integer.parseInt(pathParts[1]));

                    if (usuarioOptional.isPresent()) {
                        Usuario usuario = usuarioOptional.get();
                        request.setAttribute("usuario", usuario);
                        dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/detalle-usuarios.jsp");
                    } else {
                        response.sendRedirect(request.getContextPath() + "/tienda/usuarios");
                        return; // Detiene la ejecución aquí, después de sendRedirect
                    }

                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    // Si el ID no es un número, vuelve a la lista
                    dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");
                }

                // Ruta /editar/{id}
            } else if (pathParts.length == 3 && "editar".equals(pathParts[1])) {
                UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

                try {
                    Optional<Usuario> usuarioOptional = usuarioDAO.find(Integer.parseInt(pathParts[2]));

                    if (usuarioOptional.isPresent()) {
                        Usuario usuario = usuarioOptional.get();
                        request.setAttribute("usuario", usuario);
                        dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/editar-usuarios.jsp");
                    } else {
                        response.sendRedirect(request.getContextPath() + "/tienda/usuarios");
                        return; // Detiene la ejecución aquí después de sendRedirect
                    }

                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    // Si el ID no es un número, vuelve a la lista
                    dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");
                }

                // Ruta por defecto (catch-all para rutas no soportadas)
            } else {
                System.out.println("Opción GET no soportada: " + pathInfo);
                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");
            }
        }

        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String pathInfo = request.getPathInfo();
        pathInfo = pathInfo.replaceAll("/$", "");



        RequestDispatcher dispatcher;

        String __method__ = request.getParameter("__method__");

        if (pathInfo != null && pathInfo.endsWith("/login")) {
            UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

            String usuario = request.getParameter("usuario");
            String contraseña = request.getParameter("contraseña");
            Optional<Usuario> usuarioLogadoOpt = usuarioDAO.encontrarUsuario(usuario, contraseña);

            if (usuarioLogadoOpt.isPresent()) {
                HttpSession session = request.getSession(true);
                session.setAttribute("usuario-logado", usuarioLogadoOpt.get());
                session.setAttribute("mensaje", "Bienvenido, " + usuarioLogadoOpt.get().getNombreUsuario());

                response.sendRedirect(request.getContextPath() + "/");
                return;

            } else {

                request.setAttribute("errorLogin", usuario);

                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/login.jsp");
                dispatcher.forward(request, response);

                return;
            }

        } else if (pathInfo != null && pathInfo.endsWith("/logout")) {

            HttpSession session = request.getSession(false);

            if (session != null) {
                session.invalidate();
            }

            response.sendRedirect(request.getContextPath() + "/");
            return;

        } else {
            if (__method__ == null) {
                UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

                String nombreUsuario = request.getParameter("nombreUsuario");
                String contraseña = request.getParameter("contraseña");
                String rol = request.getParameter("rol");

                Usuario usuario = new Usuario();
                usuario.setNombreUsuario(nombreUsuario);
                usuario.setContraseña(contraseña);
                usuario.setRol(rol);
                usuarioDAO.create(usuario);
                response.sendRedirect(request.getContextPath() + "/tienda/usuarios");
                return;

            } else if ("put".equals(__method__)) {

                doPut(request, response);
                response.sendRedirect(request.getContextPath() + "/tienda/usuarios");
                return;
            } else if ("delete".equals(__method__)) {
                doDelete(request, response);
                response.sendRedirect(request.getContextPath() + "/tienda/usuarios");
                return;
            } else {
                System.out.println("OPCION POST NO SOPORTADA");
                response.sendRedirect(request.getContextPath() + "/tienda/usuarios");
                return;
            }

        }

    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String nombreUsuario = request.getParameter("nombreUsuario");
            String contraseña = request.getParameter("contraseña");
            String rol = request.getParameter("rol");

            Usuario usuario = new Usuario();
            usuario.setId(id);
            usuario.setNombreUsuario(nombreUsuario);
            usuario.setContraseña(contraseña);
            usuario.setRol(rol);

            usuarioDAO.update(usuario);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            usuarioDAO.delete(id);
        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
        }

    }
}