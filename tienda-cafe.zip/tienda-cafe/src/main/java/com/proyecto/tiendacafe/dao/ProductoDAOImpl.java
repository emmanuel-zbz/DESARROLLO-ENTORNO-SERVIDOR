package com.proyecto.tiendacafe.dao;

import com.proyecto.tiendacafe.model.Producto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProductoDAOImpl extends AbstractDAOImpl implements ProductoDAO {

    @Override
    public synchronized void create(Producto producto) {
        String sql = "INSERT INTO productos (nombre, descripcion, precio, id_categoria) VALUES (?, ?, ?, ?)";

        try (Connection conn = connectDB();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            int idx = 1;
            ps.setString(idx++, producto.getNombre());
            ps.setString(idx++, producto.getDescripcion());
            ps.setDouble(idx++, producto.getPrecio());
            ps.setInt(idx, producto.getIdCategoria());

            int rows = ps.executeUpdate();
            if (rows == 0) System.out.println("INSERT de producto con 0 filas.");

            try (ResultSet rsGenKeys = ps.getGeneratedKeys()) {
                if (rsGenKeys.next()) producto.setIdProducto(rsGenKeys.getInt(1));
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Producto> getAll() {
        List<Producto> listProd = new ArrayList<>();
        String sql = "SELECT * FROM productos";

        try (Connection conn = connectDB();
             Statement s = conn.createStatement();
             ResultSet rs = s.executeQuery(sql)) {

            while (rs.next()) {
                Producto prod = new Producto();
                prod.setIdProducto(rs.getInt("id"));
                prod.setNombre(rs.getString("nombre"));
                prod.setDescripcion(rs.getString("descripcion"));
                prod.setPrecio(rs.getDouble("precio"));
                prod.setIdCategoria(rs.getInt("id_categoria"));
                listProd.add(prod);
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return listProd;
    }

    @Override
    public Optional<Producto> find(int id) {
        String sql = "SELECT * FROM productos WHERE id = ?";

        try (Connection conn = connectDB();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Producto prod = new Producto();
                    prod.setIdProducto(rs.getInt("id"));
                    prod.setNombre(rs.getString("nombre"));
                    prod.setDescripcion(rs.getString("descripcion"));
                    prod.setPrecio(rs.getDouble("precio"));
                    prod.setIdCategoria(rs.getInt("id_categoria"));
                    return Optional.of(prod);
                }
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public void update(Producto producto) {
        String sql = "UPDATE productos SET nombre = ?, descripcion = ?, precio = ?, id_categoria = ? WHERE id = ?";

        try (Connection conn = connectDB();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            int idx = 1;
            ps.setString(idx++, producto.getNombre());
            ps.setString(idx++, producto.getDescripcion());
            ps.setDouble(idx++, producto.getPrecio());
            ps.setInt(idx++, producto.getIdCategoria());
            ps.setInt(idx, producto.getIdProducto());

            ps.executeUpdate();

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM productos WHERE id = ?";

        try (Connection conn = connectDB();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Producto> encuentraCoincidencia(String nombre) {
        return List.of();
    }


}