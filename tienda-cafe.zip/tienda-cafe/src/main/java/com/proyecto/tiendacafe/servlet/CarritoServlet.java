package com.proyecto.tiendacafe.servlet;

import com.proyecto.tiendacafe.dao.ProductoDAO;
import com.proyecto.tiendacafe.dao.ProductoDAOImpl;
import com.proyecto.tiendacafe.model.Carrito;
import com.proyecto.tiendacafe.model.Producto;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Optional;

@WebServlet(name = "carritoServlet", value = "/tienda/carrito/*")
public class CarritoServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/jsp/carrito/ver-carrito.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Carrito carrito = (Carrito) session.getAttribute("carrito");

        if (carrito == null) {
            carrito = new Carrito();
            session.setAttribute("carrito", carrito);
        }

        String __method__ = request.getParameter("__method__");

        if ("add".equalsIgnoreCase(__method__)) {
            addProducto(request, carrito);

        } else if ("remove".equalsIgnoreCase(__method__) || "delete".equalsIgnoreCase(__method__)) {
            doDelete(request, response);

        } else if ("clear".equalsIgnoreCase(__method__)) {
            carrito.vaciar();
        }

        String referer = request.getHeader("Referer");
        response.sendRedirect(referer != null ? referer : request.getContextPath() + "/tienda/productos");
    }


    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        Carrito carrito = (Carrito) session.getAttribute("carrito");

        if (carrito != null) {
            try {
                int idProd = Integer.parseInt(request.getParameter("idProducto"));
                carrito.quitarProducto(idProd);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
    }

    private void addProducto(HttpServletRequest request, Carrito carrito) {
        try {
            int idProd = Integer.parseInt(request.getParameter("idProducto"));
            int cantidad = 1;

            ProductoDAO prodDAO = new ProductoDAOImpl();
            Optional<Producto> optProd = prodDAO.find(idProd);

            if (optProd.isPresent()) {
                carrito.agregarProducto(optProd.get(), cantidad);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }


}