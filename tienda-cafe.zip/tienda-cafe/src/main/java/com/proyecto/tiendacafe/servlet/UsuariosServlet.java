package com.proyecto.tiendacafe.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.proyecto.tiendacafe.dao.UsuarioDAO;
import com.proyecto.tiendacafe.dao.UsuarioDAOImpl;
import com.proyecto.tiendacafe.model.Usuario;

import java.io.IOException;
import java.util.Optional;

@WebServlet(name = "usuariosServlet", value = "/tienda/usuarios/*")
public class UsuariosServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        RequestDispatcher dispatcher;
        String pathInfo = request.getPathInfo();

        if (pathInfo != null && pathInfo.endsWith("/logout")) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate();
            }
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        if (pathInfo == null || "/".equals(pathInfo)) {
            UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
            request.setAttribute("listaUsuarios", usuarioDAO.getAll());
            dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");

        } else {
            pathInfo = pathInfo.replaceAll("/$", "");
            String[] pathParts = pathInfo.split("/");

            if (pathParts.length == 2 && "crear".equals(pathParts[1])) {
                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/crear-usuarios.jsp");

            } else if (pathParts.length == 2 && "login".equals(pathParts[1])) {
                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/login.jsp");

            } else if (pathParts.length == 2) {
                UsuarioDAO usuarioDao = new UsuarioDAOImpl();
                try {
                    Optional<Usuario> usuarioOptional = usuarioDao.find(Integer.parseInt(pathParts[1]));
                    if (usuarioOptional.isPresent()) {
                        request.setAttribute("usuario", usuarioOptional.get());
                        dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/detalle-usuarios.jsp");
                    } else {
                        response.sendRedirect(request.getContextPath() + "/tienda/usuarios");
                        return;
                    }
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");
                }

            } else if (pathParts.length == 3 && "editar".equals(pathParts[1])) {
                UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
                try {
                    Optional<Usuario> usuarioOptional = usuarioDAO.find(Integer.parseInt(pathParts[2]));
                    if (usuarioOptional.isPresent()) {
                        request.setAttribute("usuario", usuarioOptional.get());
                        dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/editar-usuarios.jsp");
                    } else {
                        response.sendRedirect(request.getContextPath() + "/tienda/usuarios");
                        return;
                    }
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");
                }

            } else {
                System.out.println("Opción GET no soportada: " + pathInfo);
                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/usuarios.jsp");
            }
        }
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String pathInfo = request.getPathInfo();
        if (pathInfo != null) pathInfo = pathInfo.replaceAll("/$", "");

        RequestDispatcher dispatcher;
        String __method__ = request.getParameter("__method__");

        if (pathInfo != null && pathInfo.endsWith("/login")) {
            UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

            String usuario = request.getParameter("usuario");
            String password = request.getParameter("password");

            Optional<Usuario> usuarioLogadoOpt = usuarioDAO.encontrarUsuario(usuario, password);

            if (usuarioLogadoOpt.isPresent()) {
                HttpSession session = request.getSession(true);
                session.setAttribute("usuario-logado", usuarioLogadoOpt.get());
                String nombreMostrar = usuarioLogadoOpt.get().getNombreCompleto() != null
                        ? usuarioLogadoOpt.get().getNombreCompleto()
                        : usuarioLogadoOpt.get().getUsuario();

                session.setAttribute("mensaje", "Bienvenido, " + nombreMostrar);
                response.sendRedirect(request.getContextPath() + "/");
                return;

            } else {
                request.setAttribute("errorLogin", "Usuario o contraseña incorrectos");
                request.setAttribute("usuarioPrevio", usuario);
                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/usuarios/login.jsp");
                dispatcher.forward(request, response);
                return;
            }

        } else {
            if (__method__ == null) {
                UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

                String usuarioParam = request.getParameter("usuario");
                String password = request.getParameter("password");
                String rol = request.getParameter("rol");
                String nombreCompleto = request.getParameter("nombreCompleto");
                String direccion = request.getParameter("direccion");

                Usuario usuario = new Usuario();
                usuario.setUsuario(usuarioParam);
                usuario.setPassword(password);
                usuario.setRol(rol);
                usuario.setNombreCompleto(nombreCompleto);
                usuario.setDireccion(direccion);

                usuarioDAO.create(usuario);
                response.sendRedirect(request.getContextPath() + "/tienda/usuarios");

            } else if ("put".equals(__method__)) {
                doPut(request, response);
                response.sendRedirect(request.getContextPath() + "/tienda/usuarios");

            } else if ("delete".equals(__method__)) {
                doDelete(request, response);
                response.sendRedirect(request.getContextPath() + "/tienda/usuarios");

            } else {
                System.out.println("OPCION POST NO SOPORTADA");
                response.sendRedirect(request.getContextPath() + "/tienda/usuarios");
            }
        }
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String usuarioParam = request.getParameter("usuario");
            String password = request.getParameter("password");
            String rol = request.getParameter("rol");
            String nombreCompleto = request.getParameter("nombreCompleto");
            String direccion = request.getParameter("direccion");

            Usuario usuario = new Usuario();
            usuario.setId(id);
            usuario.setUsuario(usuarioParam);
            usuario.setPassword(password);
            usuario.setRol(rol);
            usuario.setNombreCompleto(nombreCompleto);
            usuario.setDireccion(direccion);

            usuarioDAO.update(usuario);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            usuarioDAO.delete(id);
        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
        }
    }
}