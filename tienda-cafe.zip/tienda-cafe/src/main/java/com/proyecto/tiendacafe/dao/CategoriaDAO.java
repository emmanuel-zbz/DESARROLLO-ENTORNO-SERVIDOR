package com.proyecto.tiendacafe.dao;

import com.proyecto.tiendacafe.model.Categoria;

import java.util.List;
import java.util.Optional;

public interface CategoriaDAO {
    public void create(Categoria categoria);
    public List<Categoria> getAll();
    public Optional<Categoria> find(int id);
    public void update(Categoria categoria);
    public void delete(int id);
    public Integer getCountProductos(int id);

}
