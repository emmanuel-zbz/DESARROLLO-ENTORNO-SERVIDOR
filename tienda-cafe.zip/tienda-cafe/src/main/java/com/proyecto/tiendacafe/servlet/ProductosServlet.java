package com.proyecto.tiendacafe.servlet;

import com.proyecto.tiendacafe.dao.CategoriaDAO;
import com.proyecto.tiendacafe.dao.CategoriaDAOImpl;
import com.proyecto.tiendacafe.dao.ProductoDAO;
import com.proyecto.tiendacafe.dao.ProductoDAOImpl;
import com.proyecto.tiendacafe.model.Producto;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "productosServlet", value = "/tienda/productos/*")
public class ProductosServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        RequestDispatcher dispatcher;
        String pathInfo = request.getPathInfo();

        if (pathInfo == null || "/".equals(pathInfo)) {
            ProductoDAO prodDAO = new ProductoDAOImpl();

            request.setAttribute("listaProductos", prodDAO.getAll());


            dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/productos/productos.jsp");

        } else {

            pathInfo = pathInfo.replaceAll("/$", "");
            String[] pathParts = pathInfo.split("/");

            if (pathParts.length == 2 && "crear".equals(pathParts[1])) {
                CategoriaDAO catDAO = new CategoriaDAOImpl();
                request.setAttribute("listaCategorias", catDAO.getAll());
                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/productos/crear-producto.jsp");

            } else {
                dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/productos/productos.jsp");
            }
        }

        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String __method__ = request.getParameter("__method__");

        if (__method__ == null) {
            ProductoDAO prodDAO = new ProductoDAOImpl();
            Producto prod = new Producto();

            prod.setNombre(request.getParameter("nombre"));
            prod.setDescripcion(request.getParameter("descripcion"));
            try {
                prod.setPrecio(Double.parseDouble(request.getParameter("precio")));
                prod.setIdCategoria(Integer.parseInt(request.getParameter("idCategoria")));
                prodDAO.create(prod);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }

        } else if ("put".equalsIgnoreCase(__method__)) {
            doPut(request, response);

        } else if ("delete".equalsIgnoreCase(__method__)) {
            doDelete(request, response);
        }

        response.sendRedirect(request.getContextPath() + "/tienda/productos");
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ProductoDAO prodDAO = new ProductoDAOImpl();
        Producto prod = new Producto();

        try {
            prod.setIdProducto(Integer.parseInt(request.getParameter("idProducto")));
            prod.setNombre(request.getParameter("nombre"));
            prod.setDescripcion(request.getParameter("descripcion"));
            prod.setPrecio(Double.parseDouble(request.getParameter("precio")));
            prod.setIdCategoria(Integer.parseInt(request.getParameter("idCategoria")));

            prodDAO.update(prod);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ProductoDAO prodDAO = new ProductoDAOImpl();
        try {
            int id = Integer.parseInt(request.getParameter("idProducto"));
            prodDAO.delete(id);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }
}