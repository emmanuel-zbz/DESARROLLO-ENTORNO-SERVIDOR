package com.proyecto.tiendacafe.dao;



import com.proyecto.tiendacafe.model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class UsuarioDAOImpl extends AbstractDAOImpl implements UsuarioDAO {

    @Override
    public void create(Usuario usuario) {
        String sql = "INSERT INTO usuarios (usuario, password, rol, nombre_completo, direccion) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = connectDB();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            int idx = 1;
            ps.setString(idx++, usuario.getUsuario());
            ps.setString(idx++, usuario.getPassword());
            ps.setString(idx++, usuario.getRol());
            ps.setString(idx++, usuario.getNombreCompleto());
            ps.setString(idx, usuario.getDireccion());

            int rows = ps.executeUpdate();
            if (rows == 0) System.out.println("INSERT de usuario con 0 filas insertadas.");

            try (ResultSet rsGenKeys = ps.getGeneratedKeys()) {
                if (rsGenKeys.next()) usuario.setId(rsGenKeys.getInt(1));
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Usuario> getAll() {
        List<Usuario> listaUsuarios = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";

        try (Connection conn = connectDB();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("id"));
                usuario.setUsuario(rs.getString("usuario"));
                usuario.setPassword(rs.getString("password"));
                usuario.setRol(rs.getString("rol"));
                usuario.setNombreCompleto(rs.getString("nombre_completo"));
                usuario.setDireccion(rs.getString("direccion"));
                listaUsuarios.add(usuario);
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return listaUsuarios;
    }

    @Override
    public Optional<Usuario> find(int id) {
        String sql = "SELECT * FROM usuarios WHERE id = ?";

        try (Connection conn = connectDB();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setId(rs.getInt("id"));
                    usuario.setUsuario(rs.getString("usuario"));
                    usuario.setPassword(rs.getString("password"));
                    usuario.setRol(rs.getString("rol"));
                    usuario.setNombreCompleto(rs.getString("nombre_completo"));
                    usuario.setDireccion(rs.getString("direccion"));
                    return Optional.of(usuario);
                }
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public void update(Usuario usuario) {
        // Implementar actualización si es necesario
    }

    @Override
    public void delete(int id) {
        // Implementar borrado si es necesario
    }

    public Optional<Usuario> encontrarUsuario(String usuario, String password) {
        String sql = "SELECT * FROM usuarios WHERE usuario = ? AND password = ?";

        try (Connection conn = connectDB();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, usuario);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario user = new Usuario();
                    user.setId(rs.getInt("id"));
                    user.setUsuario(rs.getString("usuario"));
                    user.setPassword(rs.getString("password"));
                    user.setRol(rs.getString("rol"));
                    user.setNombreCompleto(rs.getString("nombre_completo"));
                    user.setDireccion(rs.getString("direccion"));
                    return Optional.of(user);
                }
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }
}