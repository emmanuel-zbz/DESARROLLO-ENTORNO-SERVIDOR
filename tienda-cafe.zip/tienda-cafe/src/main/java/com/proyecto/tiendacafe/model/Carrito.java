package com.proyecto.tiendacafe.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Carrito implements Serializable {

    private List<LineaCarrito> lineas = new ArrayList<>();

    public List<LineaCarrito> getLineas() {
        return lineas;
    }

    // Lógica para no repetir productos, sino sumar cantidad
    public void agregarProducto(Producto producto, int cantidad) {
        for (LineaCarrito linea : lineas) {
            if (linea.getProducto().getIdProducto() == producto.getIdProducto()) {
                linea.setCantidad(linea.getCantidad() + cantidad);
                return;
            }
        }
        lineas.add(new LineaCarrito(producto, cantidad));
    }

    public void quitarProducto(int idProducto) {
        lineas.removeIf(linea -> linea.getProducto().getIdProducto() == idProducto);
    }

    public void vaciar() {
        lineas.clear();
    }

    public double getTotal() {
        return lineas.stream().mapToDouble(LineaCarrito::getSubtotal).sum();
    }

    public int getConteoArticulos() {
        return lineas.stream().mapToInt(LineaCarrito::getCantidad).sum();
    }
}